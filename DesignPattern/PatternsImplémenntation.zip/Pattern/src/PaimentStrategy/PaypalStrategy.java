package PaimentStrategy;

public class PaypalStrategy implements PaymentStrategy {
	private String emailId;
	private String password;

	public PaypalStrategy(String email, String pwd) {
		this.emailId = email;
		this.password = pwd;
	}
	//// ******* Paypal strategy *****/////

	@Override
	public void pay(int amount) {
		System.out.println(amount + " paid using Paypal.");
		System.out.println("coordonn�es de paypal : email  " + getEmailId() + " et le passeword  " + getPassword());
	}

	//// ******* getter and setter *****/////
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
