package PaimentStrategy;

public class CreditCardStrategy implements PaymentStrategy {
	private String name;
	private String cardNumber;
	private String cvv;
	private String dateOfExpiry;

	public CreditCardStrategy(String name, String CardNum, String cvv, String date) {
		this.name = name;
		this.cardNumber = CardNum;
		this.cvv = cvv;
		this.dateOfExpiry = date;

	}

	////// ************* Strategy de paiment par carte de cr�dit
	////// ********//////////////////

	@Override
	public void pay(int amount) {
		System.out.println(amount + " paid with credit/debit card");
		System.out.println("Coordonn�es de carte de cr�dit" + getName() + "  le num�ro  " + getCardNumber()
				+ " le code cvv " + getCvv() + " date expiration  " + getDateOfExpiry());

	}

//////************* Getters and Setters  **************************//////////////////

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getDateOfExpiry() {
		return dateOfExpiry;
	}

	public void setDateOfExpiry(String dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}

}
