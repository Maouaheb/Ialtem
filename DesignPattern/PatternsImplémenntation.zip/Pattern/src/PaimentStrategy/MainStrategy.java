package PaimentStrategy;

import java.util.Scanner;

public class MainStrategy {
	public static void main(String[] args) {
		ShoppingCart cart = new ShoppingCart();

		Item item1 = new Item("1234", 10);
		Item item2 = new Item("5678", 40);

		cart.addItem(item1);
		cart.addItem(item2);

		Scanner myObj = new Scanner(System.in); // Create a Scanner object
		System.out.println("Enter paiment straegy : press 1 for creditcard and 2 for paypal ");
		String strategyUser = myObj.nextLine();
		// pay by paypal
		if (strategyUser.equals("2")) {
			cart.pay(new PaypalStrategy("myemail@example.com", "mypwd"));
		}
		// pay by credit card
		if (strategyUser.equals("1")) {
			cart.pay(new CreditCardStrategy("Pankaj Kumar", "1234567890123456", "786", "12/15"));
		}
	}
}
