package Memento;

public class StatefullClass {
	private String state;

	public StatefullClass(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public MementoClass save() {
		return new MementoClass(state);
	}

	public void restore(MementoClass memento) {
		this.state = memento.getState();
	}

}
