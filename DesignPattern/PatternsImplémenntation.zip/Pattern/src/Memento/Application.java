package Memento;

public class Application {

	public static void main(String[] args) {
		Application app = new Application();
		// TODO Auto-generated method stub
		StatefullClass word = new StatefullClass("State 1");
		CareTaker prog = new CareTaker();
		word.setState("State 1");
		prog.addElement(word.save());
		app.printstack(word);
		word.setState("State 2");
		prog.addElement(word.save());
		app.printstack(word);
		word.restore(prog.undo());
		app.printstack(word);
	}

	public void printstack(StatefullClass s) {
		System.out.println("the current state " + s.getState());
	}

}
