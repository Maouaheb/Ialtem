package Memento;

public class MementoClass {
	private String state;

	public MementoClass(String state) {
		this.state = state;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
