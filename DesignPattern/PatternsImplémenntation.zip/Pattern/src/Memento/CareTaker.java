package Memento;

import java.util.ArrayList;

public class CareTaker {
	public ArrayList<MementoClass> history;
	private int currentstate = -1;

	public CareTaker() {
		history = new ArrayList<MementoClass>();
	}

	public void addElement(MementoClass m) {
		history.add(m);
	}

	public MementoClass getElement(int index) {
		return history.get(index);
	}

	public MementoClass undo() {
		System.out.println("undo last modification");
		if (currentstate <= 0) {
			currentstate = 0;
			return getElement(0);
		}
		currentstate--;
		return getElement(currentstate);

	}

	public MementoClass redo() {
		System.out.println("redo last modification");

		if (currentstate >= history.size() - 1) {
			currentstate = history.size() - 1;
			return getElement(currentstate);
		}
		currentstate++;
		return getElement(currentstate);

	}
}
