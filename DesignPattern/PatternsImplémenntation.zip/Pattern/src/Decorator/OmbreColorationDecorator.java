package Decorator;

public class OmbreColorationDecorator extends ShapeDecorator {

	public OmbreColorationDecorator(Shape decoratedShape) {
		super(decoratedShape);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("adding ombre to the shape");
	}

}
