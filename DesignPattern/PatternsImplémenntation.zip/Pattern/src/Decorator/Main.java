package Decorator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape rectangleBrut = new Rectangle();
		rectangleBrut.draw();
		Shape rectangleRed = new RedShapeDecorator(rectangleBrut);
		rectangleRed.draw();
		Shape rectangleOmbre = new OmbreColorationDecorator(rectangleRed);
		rectangleOmbre.draw();
	}

}
