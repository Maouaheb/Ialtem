package DecoratorGraph;

public abstract class Decorator implements Graph {
	Graph d;

	public Decorator(Graph d) {
		this.d = d;
	}

	public void draw() {
		d.draw();
	}
}
