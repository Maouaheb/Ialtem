package DecoratorGraph;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Graph node = new Node();
		Decorator decorator = new DecoratorThreeD(node);
		decorator.draw();
		DecoratorOmbre ombre = new DecoratorOmbre(decorator);
		ombre.draw();
	}

}
