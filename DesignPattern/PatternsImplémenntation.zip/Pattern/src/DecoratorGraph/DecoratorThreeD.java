package DecoratorGraph;

public class DecoratorThreeD extends Decorator {

	public DecoratorThreeD(Graph d) {
		super(d);
		// TODO Auto-generated constructor stub
	}

	public void draw() {
		System.out.println("adding effect 3D");
	}

}
