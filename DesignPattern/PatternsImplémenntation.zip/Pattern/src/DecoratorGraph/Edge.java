package DecoratorGraph;

public class Edge extends Element {

}
