package DecoratorGraph;

public class Element implements Graph {
	public void draw() {
		System.out.println("the basic draww");
	}

}
