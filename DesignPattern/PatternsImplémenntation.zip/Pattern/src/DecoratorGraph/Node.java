package DecoratorGraph;

public class Node extends Element {

}
