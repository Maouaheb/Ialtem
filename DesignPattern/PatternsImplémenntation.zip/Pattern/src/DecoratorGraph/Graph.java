package DecoratorGraph;

public interface Graph {
	public void draw();
}
