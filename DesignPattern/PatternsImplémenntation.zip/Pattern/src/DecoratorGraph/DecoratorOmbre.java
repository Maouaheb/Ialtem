package DecoratorGraph;

public class DecoratorOmbre extends Decorator {
	Graph d;

	public DecoratorOmbre(Graph d) {
		super(d);
		// TODO Auto-generated constructor stub
	}

	public void draw() {
		System.out.println("Ombre decorator");
		setRedBorder(d);
	}

	public void setRedBorder(Graph decoratedShape) {
		// Display message whenever function is called
		System.out.println("Border Color: Red");
	}
}
