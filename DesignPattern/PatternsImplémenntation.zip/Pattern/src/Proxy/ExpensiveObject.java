package Proxy;

public interface ExpensiveObject {
	public void process();

}
