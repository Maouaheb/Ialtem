package Proxy;

public class Proxy implements ExpensiveObject {
	public ExpensiveObject object = null;

	@Override
	public void process() {
		// TODO Auto-generated method stub
		if (object == null) {
			object = new ExpensiveObjectImplementation();
		}
		object.process();

	}

}
