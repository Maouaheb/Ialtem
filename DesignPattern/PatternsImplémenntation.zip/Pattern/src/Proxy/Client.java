package Proxy;

public class Client {
	public static void main(String[] args) {
		ExpensiveObject proxy = new Proxy();
		proxy.process();
		proxy.process();
	}
}
