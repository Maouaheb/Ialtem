package Proxy;

public class ExpensiveObjectImplementation implements ExpensiveObject {
	public ExpensiveObjectImplementation() {
		// TODO Auto-generated constructor stub
		heavyconfiguration();
	}

	@Override
	public void process() {
		// TODO Auto-generated method stub
		System.out.println("process executed to the  object");

	}

	public void heavyconfiguration() {
		System.out.println("configuring object");
	}

}
