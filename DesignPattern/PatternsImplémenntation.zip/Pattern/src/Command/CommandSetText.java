package Command;

public class CommandSetText extends Command {
	private String text;

	public CommandSetText(Document document, String s) {
		super(document);

		assert document != null;
		assert s != null;

		text = s;
	}

	@Override
	public void doIt() {
		super.doIt();
		document.set(text);
	}
}
