package Visitor;

public class CarElementDoVisitor implements Visitor {

	@Override
	public void visit(Book book) {
		System.out.println("buy book ");
	}

	@Override
	public void visit(CD cd) {
		System.out.println("buy CD ");

	}

	@Override
	public void visit(DVD dvd) {
		System.out.println("buy DVD ");

	}

	public void visitPanier(Panier panier) {
		System.out.println("\n Buying items");
		for (Visitable element : panier.getItems()) {
			element.accept(this);
		}
		System.out.println("Buy item");
	}

}
