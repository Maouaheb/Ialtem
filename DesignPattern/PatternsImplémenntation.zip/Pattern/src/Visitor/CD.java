package Visitor;

public class CD implements Visitable {
	private String s�rie;
	private String chanteur;

	public CD(String s, String chanteur) {
		this.s�rie = s;
		this.chanteur = chanteur;
	}

	public String getS�rie() {
		return s�rie;
	}

	public String getChanteur() {
		return chanteur;
	}

	@Override
	public void accept(Visitor visitor) {
		visitor.visit(this);
	}

}
