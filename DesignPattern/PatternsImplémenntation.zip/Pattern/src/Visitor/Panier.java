package Visitor;

public class Panier {
	Visitable[] items;

	public Visitable[] getItems() {
		return items;
	}

	public Panier() {
		this.items = new Visitable[] { new CD("1245", "Celine Dion"), new Book("Ce que doit le jour � la nuit"),
				new Book("Alchimiste"), new DVD("film Harry Potter") };
	}
}
