package Visitor;

public class Book implements Visitable {
	private String name;

	public String getName() {
		return name;
	}

	public Book(String n) {
		this.name = n;
	}

	@Override
	public void accept(Visitor visitor) {
		visitor.visit(this);
	}

}
