package Visitor;

public class Main {
	public static void main(String[] args) {
		Panier panier = new Panier();
		CarElementDoVisitor traitement1 = new CarElementDoVisitor();
		traitement1.visitPanier(panier);
		TraitementAffichage traitement2 = new TraitementAffichage();
		traitement2.visitPanier(panier);
	}
}
