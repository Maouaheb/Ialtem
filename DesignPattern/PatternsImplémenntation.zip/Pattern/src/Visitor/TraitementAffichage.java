package Visitor;

public class TraitementAffichage implements Visitor {

	@Override
	public void visit(Book book) {
		System.out.println("Visiting book name " + book.getName());
	}

	@Override
	public void visit(CD cd) {
		System.out.println("Visiting CD s�rie" + cd.getS�rie() + " du chanteur " + cd.getChanteur());
	}

	@Override
	public void visit(DVD dvd) {
		System.out.println("Visiting DVD name" + dvd.getName());
	}

	public void visitPanier(Panier panier) {
		System.out.println("\nVisiting car");
		for (Visitable element : panier.getItems()) {
			element.accept(this);
		}
		System.out.println("Visited car");
	}

}
