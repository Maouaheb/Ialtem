package Thread;

public class Main {

	public static void main(String[] args) {

		// Shared queue
		SharedQueue<Tree> inPool = new SharedQueue<Tree>();
		SharedQueue<Tree> inChecker = new SharedQueue<Tree>();

		// Thread to create a tree
		ThreadCreator creatorJob = new ThreadCreator(inPool);
		Thread creator = new Thread(creatorJob);
		creator.start();

		// create the 32 thread pool
		ThreadPool poolJob = new ThreadPool(inPool, inChecker);
		for (int i = 0; i < 32; i++) {
			Thread pool = new Thread(poolJob);
			pool.start();
		}

		// Thread to check the integrity
		ThreadChecker checkerJob = new ThreadChecker(inChecker, inPool);
		Thread checker = new Thread(checkerJob);
		checker.start();
	}

}
