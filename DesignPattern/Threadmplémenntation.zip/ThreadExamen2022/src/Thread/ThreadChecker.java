package Thread;

public class ThreadChecker implements Runnable {
	SharedQueue<Tree> in;
	SharedQueue<Tree> out;

	public ThreadChecker(SharedQueue<Tree> in, SharedQueue<Tree> out) {
		// TODO Auto-generated constructor stub
		this.in = in;
		this.out = out;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		Tree t = in.getItem();
		if (t.checkIntegrity()) {
			out.add(t);
		} else {
			System.out.println("error");
		}

	}

}
