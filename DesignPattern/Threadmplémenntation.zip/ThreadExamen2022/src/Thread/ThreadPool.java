package Thread;

public class ThreadPool implements Runnable {
	SharedQueue<Tree> in;
	SharedQueue<Tree> out;

	public ThreadPool(SharedQueue<Tree> in, SharedQueue<Tree> out) {
		// TODO Auto-generated constructor stub
		this.in = in;
		this.out = out;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (in.size() > 0) {
			Tree t = in.getItem();
			if (t.size() > 1021) {
				// getleft and getright and send it again to the same pool
				in.add(t.getLeft());
				in.add(t.getRight());
			} else {
				t.process();
			}
		}

	}

}
