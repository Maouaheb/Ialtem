package Thread;

public class Util {
	Tree tree;

	public Tree generateTree() {
		return tree;
	}
}
