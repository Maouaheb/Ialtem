package Thread;

public interface Tree {
	Tree getLeft();

	Tree getRight();

	Object process();

	long size();

	boolean checkIntegrity();
}
