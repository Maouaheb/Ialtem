package Thread;

public class ThreadCreator implements Runnable {
	public SharedQueue<Tree> queue;

	public ThreadCreator(SharedQueue<Tree> queue) {
		// TODO Auto-generated constructor stub
		this.queue = queue;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("generate thge tree and put it in the shared queue");
		Util util = new Util();
		Tree tree = util.generateTree();
		queue.add(tree);
	}

}
