package philosophe;

public class Philosophes {

	
    private final Fourchettes[] fourchettes = new Fourchettes[5];

   
    public Philosophes(){
        putfourchetteOnTheTable();
        Thread t1 = new Thread(new Philosopher("First",this.fourchettes[4],this.fourchettes[0]));
        Thread t2 = new Thread(new Philosopher("Second",this.fourchettes[0],this.fourchettes[1]));
        Thread t3 = new Thread(new Philosopher("Third",this.fourchettes[1],this.fourchettes[2]));
        Thread t4 = new Thread(new Philosopher("Fourth",this.fourchettes[2],this.fourchettes[3]));
        Thread t5 = new Thread(new Philosopher("Fifth",this.fourchettes[3],this.fourchettes[4]));
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
    }

  
    private void putfourchetteOnTheTable(){
        for(int i = 0;i < fourchettes.length;i++)
        	fourchettes[i]= new Fourchettes(); 
    }

    public static void main(String[] args){
        new Philosophes();
    }


}
