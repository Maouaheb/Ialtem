package philosophe;

import java.util.Random;

public class Philosopher extends Thread {

	 private static final int MAX_EATING_TIME = 1000;
	    private static final int MAX_THINKING_TIME = 800;
	    private final Random randomise = new Random();
	    private final Fourchettes Fgauche;
	    private final Fourchettes Fdroite;
	    private final String _name;
	    private State _state;

	   
	    public enum State {
	        EATING, THINKING, WAITING
	    }

	   
	    public Philosopher(String name, Fourchettes Fgauche, Fourchettes Fdroite) {
	        System.out.println(name +"Started");
	        this.Fgauche = Fgauche;
	        this.Fdroite = Fdroite;
	        this._name = name;
	    }

	    
	    private void eat() throws InterruptedException {

	        synchronized(Fgauche){
	        while(Fgauche.isUsed() || Fdroite.isUsed())      
	            try{
	                this.setPhilosopherState(Philosopher.State.WAITING);
	                Fgauche.wait();;
	            }catch (InterruptedException e){}
	                synchronized(Fdroite) {
	                try{
	                    Thread.sleep(1);
	                    Fdroite.setUsed(true);
	                    Fgauche.setUsed(true);
	                    this.setPhilosopherState(Philosopher.State.EATING);
	                    Thread.sleep(randomise.nextInt(MAX_EATING_TIME));
	                }
	                finally {
	                    Fgauche.setUsed(false);
	                    Fdroite.setUsed(false); 
	                    Fgauche.notify();
	                    Fdroite.notify();   
	                }
	                }
	            }

	        think();
	    }

	    
	    private void think() throws InterruptedException{
	        this.setPhilosopherState(Philosopher.State.THINKING);
	        Thread.sleep(randomise.nextInt(MAX_THINKING_TIME));
	    }

	   
	    private void setPhilosopherState(State state){
	        this._state = state;
	        System.out.println(System.currentTimeMillis() +":"+ _state +", "+ _name+";");
	    }

	    
	    public State getPhilosopherState(){
	        return _state;
	    }

	   
	    public void run(){
	        for(int i =0; i< 10;i++){
	            try {
	                eat();
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }

	        System.out.println("Succesfully finished: " +_name);
	    }

}
