package philosophe;

public class Fourchettes {
	 private boolean _isUsed;

	   
	    public boolean isUsed(){
	        return _isUsed; 
	    }

	   
	    public void setUsed(boolean usedFlag){
	        _isUsed = usedFlag;
	    }
}
