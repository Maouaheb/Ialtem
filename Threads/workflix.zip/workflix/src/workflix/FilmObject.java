package workflix;

import java.util.List;

public class FilmObject implements Film {

	@Override
	public List<Film> split(int duration) {
		return null;
	}

	@Override
	public Film getAudioPart() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Film getVideoPart() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Film compressAudioIntoMP3() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Film compressVideoIntoMP4() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean match(Film other) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Film assemble(Film other) {
		// TODO Auto-generated method stub
		return null;
	}

}
