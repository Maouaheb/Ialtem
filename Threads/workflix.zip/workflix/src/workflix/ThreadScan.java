package workflix;

public class ThreadScan extends Thread {

	private final Queue audio;
	private final Queue video;

	public ThreadScan(Queue audio, Queue video) {
		assert audio!=null && video!=null;
		
		this.audio = audio;
		this.video = video;
	}

	public void run() {
		while (true) {
			Film film = trsfFileIntoFilm(getRawFile());
			for (Film part : film.split(10)) {
				audio.add(part);
				video.add(part);
			}
		}
	}

	private Film trsfFileIntoFilm(Object rawFile) {
		// TODO Auto-generated method stub
		return null;
	}

	private Object getRawFile() {
		return new FilmObject();
	}

}
