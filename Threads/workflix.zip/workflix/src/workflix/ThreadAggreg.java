package workflix;

import java.util.LinkedList;
import java.util.List;

public class ThreadAggreg extends Thread {

	private final Queue in;
	private final List<Film> waiting = new LinkedList<>();

	public ThreadAggreg(Queue in) {
		assert in!=null;
		
		this.in = in;
	}

	public void run() {
		while (true) {
			Film film = in.get();
			Film found = null;
			for (Film other : waiting) {
				if (film.match(other)) {
					found = other;
				}
			}
			if (found == null) {
				waiting.add(film);
			} else {
				film.assemble(found);
				waiting.remove(found);
			}
		}
	}

}
