package workflix;

public class ThreadFilmAudio extends ThreadFilm {
	
	public ThreadFilmAudio(Queue in, Queue out) {
		super(in,out);
	}

	@Override
	public Film process(Film film) {
		return film.compressAudioIntoMP3();
	}
	
}
