package workflix;

import java.util.List;

public interface Film {
	// d�coupe un film en une s�quence de films de 'duration' minutes maximum
	List<Film> split(int duration);
	
	// retourne la bande son du film
	Film getAudioPart();
	
	// retourne la bande vid�o du film
	Film getVideoPart();
	
	// produit la version compress�e de la bande audio
	Film compressAudioIntoMP3();
	
	// produit la version compress�e de la bande vid�o
	Film compressVideoIntoMP4();
	
	// true <-> this et other sont deux parties (vid�o et son) d'un m�me film
	boolean match(Film other);
	
	// agr�ge deux parties de film qui matchent ensemble
	Film assemble(Film other);
}	