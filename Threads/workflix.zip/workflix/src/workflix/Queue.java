package workflix;

import java.util.ArrayList;
import java.util.List;

public class Queue {
	List<Film> queue=new ArrayList<>();
	
	synchronized public void add(Film film) {
		assert film!=null;
		
		queue.add(film);
		notify(); 
	}

	synchronized public Film get() {
		while (queue.isEmpty()) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return queue.remove(queue.size()-1);
	}

}
