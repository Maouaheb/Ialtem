package workflix;

public class ThreadFilmVideo extends ThreadFilm {
	
	public ThreadFilmVideo(Queue in, Queue out) {
		super(in,out);
	}

	@Override
	public Film process(Film film) {
		return film.compressVideoIntoMP4();
	}

}
