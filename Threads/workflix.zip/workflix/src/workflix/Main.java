package workflix;

public class Main {

	/** class FilmObject is not implemented, 
	 *  hence, this program doesn't work.
	 *   
	 */
	
	public static void main(String[] args) {
		Queue audio=new Queue();
		Queue video=new Queue();
		Queue aggreg=new Queue();
		new ThreadScan(audio, video).start();
		for (int i=0;i<50;i++) {
			new ThreadFilmAudio(audio, aggreg).start();
			new ThreadFilmVideo(video, aggreg).start();
		}
		new ThreadAggreg(aggreg).start();
	}
}
