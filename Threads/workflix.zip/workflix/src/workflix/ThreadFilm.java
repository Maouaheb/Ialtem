package workflix;

public abstract  class ThreadFilm extends Thread {
	
	protected final Queue in;
	protected final Queue out;

	public ThreadFilm(Queue in, Queue out) {
		assert in!=null && out!=null;
		
		this.in=in;
		this.out=out;
	}
	
	abstract public Film process(Film film);
	
	public void run() {
		while (true) {
			Film film = in.get();
			Film film2 = process(film);
			out.add(film2);
		}
	}

}
