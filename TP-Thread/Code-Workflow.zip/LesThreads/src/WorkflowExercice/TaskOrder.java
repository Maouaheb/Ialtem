package WorkflowExercice;

public class TaskOrder extends Task {

	public TaskOrder(SharedQueue<Document>[] in, SharedQueue<Document>[] out) {
		super("ORDER", in, out);
		assert in.length == 1;
		assert out.length == 2;
	}

	@Override
	public void run() {
		while (true) {
			Document document = in[0].getItem();
			// afficher le nom de ce thread
			document.process(this);
			// changer la variable order dans la class document et la rendre true=> Order a
			// fini le traitement
			document.passedByOrder();
			// order doit envoyer le document aux Bill et Send
			out[0].add(document);
			out[1].add(document);
		}
	}

}
