package WorkflowExercice;

public class TaskDispatch extends Task {

	public TaskDispatch(SharedQueue<Document>[] in, SharedQueue<Document>[] out) {
		// la queue out dans la fonction main est compos�e par 3 autres queues: l'indice
		// comme de 0 � 2 ��d out[0], out[1], et out [2]
		super("DISPATCH", in, out);
		assert in.length == 1;
		assert out.length == 3;
	}

	@Override
	public void run() {
		while (true) {
			Document document = in[0].getItem();
			// process va afficher le nom de ce thread
			document.process(this);
			switch (document.getStatus()) {
			case bill:
				// envoyer le document au thread Bill avec la queue correspondante
				out[2].add(document);
				break;
			case send:
				// envoyer le document au thread Send avec la queue correspondante

				out[1].add(document);
				break;
			case order:
				// envoyer le document au thread Order avec la queue correspondante

				out[0].add(document);
				break;
			default:
				assert false : "forgotten enum";
			}

		}
	}

}
