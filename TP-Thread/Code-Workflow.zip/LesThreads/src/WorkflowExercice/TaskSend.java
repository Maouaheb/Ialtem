package WorkflowExercice;

public class TaskSend extends Task {

	public TaskSend(SharedQueue<Document>[] in, SharedQueue<Document>[] out) {
		super("SEND", in, out);
		assert in.length == 1;
		assert out.length == 1;
	}

	@Override
	public void run() {
		while (true) {
			Document document = in[0].getItem();
			// afficher le nom du thread
			document.process(this);
			// mettre le document dans la queue du Backup
			out[0].add(document);
		}
	}

}
