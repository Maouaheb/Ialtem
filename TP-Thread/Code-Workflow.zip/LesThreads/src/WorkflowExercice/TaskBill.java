package WorkflowExercice;

public class TaskBill extends Task {

	public TaskBill(SharedQueue<Document>[] in, SharedQueue<Document>[] out) {
		super("BILL", in, out);

		assert in.length == 1;
		assert out.length == 1;
	}

	@Override
	public void run() {
		while (true) {
			Document document = in[0].getItem();
			// afficher le nom du thread
			document.process(this);
			// enovyer le document � la t�che Bacup
			out[0].add(document);
		}
	}

}
