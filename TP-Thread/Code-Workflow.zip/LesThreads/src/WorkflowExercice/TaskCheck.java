package WorkflowExercice;

public class TaskCheck extends Task {

	public TaskCheck(SharedQueue<Document>[] in, SharedQueue<Document>[] out) {
		super("CHECK", in, out);

		assert in.length == 1;
		assert out.length == 2;
	}

	@Override
	public void run() {
		while (true) {
			Document document = in[0].getItem();
			document.process(this);
			if (document.isConform()) {
				// dans la fonction main nous avons cr�e une queue compos�e de 2 queue (pour
				// dispatchet pour trash)
				// out[0] is the sharedqueue for dispatch
				out[0].add(document);
			} else {
				// out[1] is the sharedqueue for trash
				out[1].add(document);
			}
		}
	}
}
